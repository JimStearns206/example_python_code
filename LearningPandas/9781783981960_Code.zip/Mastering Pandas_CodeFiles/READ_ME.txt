This package consists of Python programs and data files for the book Mastering Pandas.

The following chapters have code or data files, the rest do not:
Chapters 2, 4, 5, 6, 7, 8, 11

Note that the Python programs should be run by specifying the path to your version of Python as in:

/yourpath/python <python_prog_file>

and programs that make read a data file may have to be modified to point to the file's correct location on the user's system.
